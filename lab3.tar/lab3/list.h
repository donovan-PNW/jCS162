#ifndef LIST_H
#define LIST_H

bool insert(int position, int val, int intList[], int& size);
bool remove(int position, int& val, int intList[], int& size);
void print(const int intList[], int size);

#endif
